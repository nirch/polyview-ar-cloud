
app.directive("navbarConsumer", function() {
    return {
        templateUrl: "app/shared/navbar-consumer/navbar-consumer.html",
        restrict: "E"
    }
})